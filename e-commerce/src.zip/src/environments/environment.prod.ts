export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCSxAg1xclnW6HOFfDm6ag7QSZ90yEwGBY',
    authDomain: 'ishop-d5dba.firebaseapp.com',
    databaseURL: 'https://ishop-d5dba.firebaseio.com',
    projectId: 'ishop-d5dba',
    storageBucket: 'ishop-d5dba.appspot.com',
    messagingSenderId: '952789795979',
    appId: '1:952789795979:web:9234308c45f5c2bc'
    }
};
