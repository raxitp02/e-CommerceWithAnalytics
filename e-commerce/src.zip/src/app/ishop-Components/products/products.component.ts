import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { CategoryService } from '../../services/category.service';
import { ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';
import { Product } from '../../models/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
products$: Product[];
filteredProducts$;
categories$;
category: string;
  constructor( public productService: ProductService,
               public categoryService: CategoryService,
               public activatedRoute: ActivatedRoute) {
    this.productService.getAll().subscribe(products => {
      this.products$ = products;

      activatedRoute.queryParamMap.subscribe(params => {
        this.category = params.get('category');

        this.filteredProducts$ = (this.category) ?
        this.products$.filter(p => p.category === this.category) :
        this.products$;
      });
    });
    this.categories$ = categoryService.getCategories();
  }

  ngOnInit() {
  }

}
