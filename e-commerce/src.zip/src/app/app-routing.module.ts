import { AdminAuthguard } from './services/admin-authguard.service';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './ishop-Components/home/home.component';
import { ProductsComponent } from './ishop-Components/products/products.component';
import { ShoppingCartComponent } from './ishop-Components/shopping-cart/shopping-cart.component';
import { CheckOutComponent } from './ishop-Components/check-out/check-out.component';
import { OrderSuccessComponent } from './ishop-Components/order-success/order-success.component';
import { LoginComponent } from './login/login.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { MyOrdersComponent } from './ishop-Components/my-orders/my-orders.component';
import { AuthGuard } from './services/auth-guard.service';
import { ProductFormComponent } from './admin/product-form/product-form.component';


const iShopRoutes: Routes = [
  { path: '', component: ProductsComponent},
  { path: 'products', component: ProductsComponent},
  { path: 'shopping-cart', component: ShoppingCartComponent},
  { path: 'login', component: LoginComponent},

  { path: 'check-out', component: CheckOutComponent, canActivate: [AuthGuard] },
  { path: 'order-success', component: OrderSuccessComponent, canActivate: [AuthGuard] },
  { path: 'my/orders', component: MyOrdersComponent,  canActivate: [AuthGuard] },


  {
    path: 'admin/products/new',
    component: ProductFormComponent,
    canActivate: [AuthGuard, AdminAuthguard]
  },
  {
    path: 'admin/products/:id',
    component: ProductFormComponent,
    canActivate: [AuthGuard, AdminAuthguard]
  },
  {
    path: 'admin/products',
    component: AdminProductsComponent,
    canActivate: [AuthGuard, AdminAuthguard]
  },
  {
    path: 'admin/orders',
    component: AdminOrdersComponent,
    canActivate: [AuthGuard, AdminAuthguard]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(iShopRoutes)],
  exports: [RouterModule]})
export class IShopRoutingModule { }
