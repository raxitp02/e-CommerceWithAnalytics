import { AuthService } from './auth.service';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthguard implements CanActivate {

  constructor( private auth: AuthService, private userService: UserService) { }


  canActivate(): Observable<boolean> {
    return this.auth.appUser$.pipe(
                              map((appUser: any) => appUser.isAdmin));
    }
}
